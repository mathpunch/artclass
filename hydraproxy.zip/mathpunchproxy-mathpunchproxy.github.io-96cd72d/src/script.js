window.onload = function() {
    alert("Hydra Proxy 1.0");
};
